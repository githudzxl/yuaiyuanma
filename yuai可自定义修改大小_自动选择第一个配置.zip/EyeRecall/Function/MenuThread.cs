﻿using System;
using System.Reflection;
using EyeRecall.Helper;
using UnityEngine;

namespace EyeRecall.Function
{
    [Obfuscation(Exclude = true)]
    internal class MenuThread : MonoBehaviour
    {
        [Obfuscation(Exclude = true)]
        private void Start()
        {
        }

        [Obfuscation(Exclude = true)]
        private void OnGUI()
        {
            this.menuId = 777;
            this.menuRect = drawMenu.menuRectGlobal;
            if (drawMenu.showMenu)
            {
                float num = 10f;
                Rect rect = new Rect(this.menuRect.x - num / 2f, this.menuRect.y + num / 2f, this.menuRect.width + num, this.menuRect.height + num);
                GUI.color = new Color(0f, 0f, 0f, 0.4f);
                GUI.DrawTexture(rect, Texture2D.whiteTexture);
                GUI.color = Color.white;
                this.menuRect = GUILayout.Window(this.menuId, this.menuRect, new GUI.WindowFunction(drawMenu.run), "", new GUILayoutOption[0]);

                // ==================== 核心修正：把拖动后的位置赋回给 drawMenu.menuRectGlobal ====================
                drawMenu.menuRectGlobal = this.menuRect;
            }
            if (CheatThread._Visual.Enable && CheatThread._Visual.showAimRange)
            {
                GUI.color = Color.white;
                GizmosProGraph.DrawScreenEllipse(new Vector2((float)Screen.width / 2f, (float)Screen.height / 2f), (float)CheatThread._aimBot.aimRange, (float)CheatThread._aimBot.aimRange, Color.white, 50);
                GUI.color = Color.white;
            }
        }

        public MenuThread()
        {
        }

        public int menuId;

        public Rect menuRect;
    }
}