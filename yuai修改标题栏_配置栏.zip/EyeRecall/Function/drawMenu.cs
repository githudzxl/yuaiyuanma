﻿using System;
using System.IO;
using System.Linq;
using EyeRecall.Helper;
using UnityEngine;

namespace EyeRecall.Function
{
    internal class drawMenu
    {
        // ==================== 可自定义参数 ====================
        private static readonly float MenuAlpha = 0.65f;
        private static readonly float DragTitleBarHeight = 60f;
        internal static Rect menuRectGlobal = new Rect(50f, 50f, 1000f, 800f);
        // ======================================================

        private static GUIStyle buttonStyle;
        private static GUIStyle labelStyle;
        private static GUIStyle toggleStyle;
        private static GUIStyle toggleKnobStyle;
        private static GUIStyle sliderStyle;
        private static GUIStyle toolbarStyle;
        private static GUIStyle titleStyle;
        private static GUIStyle sectionBoxStyle;
        private static GUIStyle sectionTitleStyle;
        private static GUIStyle sliderLabelStyle;
        private static GUIStyle configSelectedStyle;

        private static int ToolBarValue;
        private static bool rageBotPosDropdown;
        private static bool bhopModeDropdown;
        private static bool antiAimModeDropdown;
        private static bool antiAimPitchModeDropdown;
        private static bool antiAimYawModeDropdown;
        private static bool resolverType;
        private static bool aimPosDropdown;
        private static bool glowColorDropdown;
        private static bool isWaitingForAimKey;
        private static bool isWaitingForThirdPressKey;
        private static readonly string waitingText = "请按键...";
        internal static bool showMenu;
        private static Vector2 mainScrollPosition;
        private static Vector2 rageBotPosScrollPosition;
        private static Vector2 autoChatMessageScrollPosition;
        private static Vector2 configScrollPosition;
        private static float borderColorTime = 0f;
        private static bool isInitialized = false;
        private static Texture2D s_gradientBackgroundTex;
        private static Texture2D s_titleBarBgTex; // 仅新增：标题栏背景

        // ==================== 配置管理相关字段 ====================
        private static string renameConfigNewName = "";
        private static bool isRenamingConfig = false;
        private static string newConfigName = "";
        private static bool isCreatingConfig = false;
        private static bool isDeletingConfig = false;
        private static int lastSelectedConfigKey = -1;
        private static int createConfigSourceIndex = 0;

        private static void UIInit()
        {
            try
            {
                GUISkin guiskin = ScriptableObject.CreateInstance<GUISkin>();
                Font font = Font.CreateDynamicFontFromOSFont(new string[] { "PingFang SC", "Microsoft YaHei", "Arial" }, 16);
                if (font == null)
                {
                    Debug.LogError("未能加载任何可用字体。");
                }
                guiskin.font = font;

                Color color = new Color(0.1f, 0.1f, 0.12f, MenuAlpha);
                Color color2 = new Color(0.18f, 0.18f, 0.22f, MenuAlpha);
                Color color3 = new Color(0.25f, 0.25f, 0.35f, MenuAlpha + 0.1f);
                Color color4 = new Color(0.35f, 0.35f, 0.45f, MenuAlpha + 0.15f);
                Color color5 = new Color(0.9f, 0.9f, 0.95f, 1f);
                Color cyan = Color.cyan;
                Color color6 = new Color(0.15f, 0.15f, 0.25f, MenuAlpha);
                Color color7 = new Color(0.25f, 0.25f, 0.45f, MenuAlpha + 0.1f);

                guiskin.window.normal.background = MakeTex(2, 2, color);
                guiskin.window.padding = new RectOffset(20, 20, 20, 20);
                guiskin.window.border = new RectOffset(0, 0, 0, 0);

                guiskin.button.normal.background = MakeTex(2, 2, color3);
                guiskin.button.hover.background = MakeTex(2, 2, color4);
                guiskin.button.active.background = MakeTex(2, 2, color4);
                guiskin.button.normal.textColor = color5;
                guiskin.button.hover.textColor = cyan;
                guiskin.button.padding = new RectOffset(15, 15, 12, 12);
                guiskin.button.alignment = TextAnchor.MiddleCenter;
                guiskin.button.fontSize = 16;

                guiskin.label.normal.textColor = color5;
                guiskin.label.fontSize = 16;

                guiskin.textArea.normal.background = MakeTex(2, 2, color3);
                guiskin.textArea.normal.textColor = color5;
                guiskin.textArea.padding = new RectOffset(8, 8, 8, 8);
                guiskin.textArea.fontSize = 16;

                toggleStyle = new GUIStyle
                {
                    normal = { background = MakeTex(54, 26, color3) },
                    onNormal = { background = MakeTex(54, 26, cyan) },
                    fixedWidth = 54f,
                    fixedHeight = 26f,
                    border = new RectOffset(2, 2, 2, 2)
                };
                toggleKnobStyle = new GUIStyle
                {
                    normal = { background = MakeTex(20, 20, Color.white) },
                    fixedWidth = 20f,
                    fixedHeight = 20f
                };

                guiskin.horizontalSlider.normal.background = MakeTex(2, 2, color2);
                guiskin.horizontalSlider.fixedHeight = 8f;
                guiskin.horizontalSliderThumb.normal.background = MakeTex(22, 22, cyan);
                guiskin.horizontalSliderThumb.hover.background = MakeTex(22, 22, cyan * 1.1f);
                guiskin.horizontalSliderThumb.fixedWidth = 22f;
                guiskin.horizontalSliderThumb.fixedHeight = 22f;
                guiskin.horizontalSliderThumb.margin = new RectOffset(0, 0, -7, 0);

                sliderLabelStyle = new GUIStyle(guiskin.label)
                {
                    alignment = TextAnchor.MiddleRight,
                    fontSize = 16
                };
                toolbarStyle = new GUIStyle(guiskin.button)
                {
                    normal = { background = MakeTex(2, 2, color6), textColor = color5 },
                    hover = { background = MakeTex(2, 2, color7), textColor = cyan },
                    onNormal = { background = MakeTex(2, 2, color7), textColor = cyan },
                    fontSize = 16,
                    alignment = TextAnchor.MiddleCenter,
                    margin = new RectOffset(0, 0, 0, 0),
                    padding = new RectOffset(20, 20, 15, 15),
                    stretchWidth = true
                };
                titleStyle = new GUIStyle(guiskin.label)
                {
                    normal = { textColor = cyan },
                    fontSize = 30,
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleCenter,
                    padding = new RectOffset(0, 0, -5, 20)// 这里控制上下内边距
                };
                sectionBoxStyle = new GUIStyle(guiskin.box)
                {
                    normal = { background = MakeTex(2, 2, color2) },
                    padding = new RectOffset(20, 20, 20, 20),
                    margin = new RectOffset(8, 8, 15, 15)
                };
                sectionTitleStyle = new GUIStyle(guiskin.label)
                {
                    normal = { textColor = cyan },
                    fontSize = 22,
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleLeft,
                    padding = new RectOffset(0, 0, 10, 15)// 这里控制上下内边距
                };

                // 配置选中高亮样式
                configSelectedStyle = new GUIStyle(guiskin.button)
                {
                    normal = { background = MakeTex(2, 2, cyan), textColor = Color.black },
                    hover = { background = MakeTex(2, 2, cyan * 1.1f), textColor = Color.black },
                    fontSize = 16,
                    fixedHeight = 40f,
                    margin = new RectOffset(2, 2, 3, 3)
                };

                GUI.skin = guiskin;
                labelStyle = GUI.skin.label;
                buttonStyle = GUI.skin.button;
                sliderStyle = GUI.skin.horizontalSliderThumb;

                // 菜单整体背景（完全不动）
                if (s_gradientBackgroundTex != null)
                {
                    UnityEngine.Object.Destroy(s_gradientBackgroundTex);
                }
                s_gradientBackgroundTex = new Texture2D(1, (int)menuRectGlobal.height);
                Color color8 = new Color(0.12f, 0.12f, 0.22f, MenuAlpha - 0.1f);
                Color color9 = new Color(0.08f, 0.08f, 0.18f, MenuAlpha - 0.1f);
                for (int i = 0; i < s_gradientBackgroundTex.height; i++)
                {
                    s_gradientBackgroundTex.SetPixel(0, i, Color.Lerp(color8, color9, (float)i / (float)s_gradientBackgroundTex.height));
                }
                s_gradientBackgroundTex.Apply();
                s_gradientBackgroundTex.hideFlags = HideFlags.HideAndDontSave;

                // ==================== 【仅新增】标题栏醒目背景 ====================
                if (s_titleBarBgTex != null)
                {
                    UnityEngine.Object.Destroy(s_titleBarBgTex);
                }
                s_titleBarBgTex = MakeTex(2, 2, new Color(0.0f, 0.4f, 0.8f, 0.05f)); // 纯深蓝色醒目背景
                s_titleBarBgTex.hideFlags = HideFlags.HideAndDontSave;
                // =====================================================================

                isInitialized = true;
            }
            catch (Exception ex)
            {
                Debug.LogError("UI初始化异常: " + ex.Message);
            }
        }

        internal static void run(int id)
        {
            try
            {
                if (!isInitialized)
                {
                    UIInit();
                }

                // 1. 绘制整体背景
                DrawGradientBackground(new Rect(0, 0, menuRectGlobal.width, menuRectGlobal.height));

                // ==================== 【仅修改】标题栏：背景 + 双高亮分隔线 ====================
                // 绘制标题栏背景
                GUI.DrawTexture(new Rect(0, 0, menuRectGlobal.width, DragTitleBarHeight), s_titleBarBgTex);
                // 顶部高亮分隔线
                GUI.color = Color.cyan;
                GUI.DrawTexture(new Rect(0, 0, menuRectGlobal.width, 3f), Texture2D.whiteTexture);
                // 底部高亮分隔线
                GUI.DrawTexture(new Rect(0, DragTitleBarHeight - 3f, menuRectGlobal.width, 3f), Texture2D.whiteTexture);
                GUI.color = Color.white;
                // ==================================================================================

                // 2. 原有内容绘制（完全不动）
                GUILayout.BeginHorizontal(new GUILayoutOption[0]);
                GUILayout.FlexibleSpace();
                GUILayout.Label("雨爱", titleStyle, new GUILayoutOption[0]);
                GUILayout.FlexibleSpace();
                GUILayout.Label(DateTime.Now.ToString("HH:mm:ss"), labelStyle, new GUILayoutOption[] { GUILayout.Width(100f) });
                GUILayout.EndHorizontal();
                GUILayout.Space(15f);
                string[] array = new string[] { "普通自瞄", "暴力自瞄", "视觉", "杂项", "反自瞄" };
                ToolBarValue = GUILayout.Toolbar(ToolBarValue, array, toolbarStyle, new GUILayoutOption[] { GUILayout.Height(45f) });
                GUILayout.Space(20f);
                mainScrollPosition = GUILayout.BeginScrollView(mainScrollPosition, false, false, new GUILayoutOption[0]);
                switch (ToolBarValue)
                {
                    case 0:
                        DrawLegitAimbotTab();
                        break;
                    case 1:
                        DrawRageAimbotTab();
                        break;
                    case 2:
                        DrawVisualsTab();
                        break;
                    case 3:
                        DrawMiscTab();
                        break;
                    case 4:
                        DrawAntiAimTab();
                        break;
                }
                GUILayout.EndScrollView();

                // 3. 拖动逻辑（完全不动）
                GUI.DragWindow(new Rect(0, 0, menuRectGlobal.width, DragTitleBarHeight));
            }
            catch (Exception ex)
            {
                Debug.LogError("菜单渲染错误: " + ex.Message);
            }
        }

        private static void DrawLegitAimbotTab()
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[] { GUILayout.Width(450f) });
            GUILayout.Label("核心设置", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._aimBot.Enable = UiToggle(CheatThread._aimBot.Enable, "启用普通自瞄");
            if (CheatThread._aimBot.Enable)
            {
                CheatThread._aimBot.LegitAimbot = UiToggle(CheatThread._aimBot.LegitAimbot, "平滑模式");
                CheatThread._aimBot.InvincibleNoAim = UiToggle(CheatThread._aimBot.InvincibleNoAim, "无敌不锁");
                CheatThread._aimBot.PassWallAim = UiToggle(CheatThread._aimBot.PassWallAim, "墙后不锁");
            }
            GUILayout.EndVertical();
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
            GUILayout.Label("参数调整", sectionTitleStyle, new GUILayoutOption[0]);
            if (CheatThread._aimBot.Enable)
            {
                if (CheatThread._aimBot.LegitAimbot)
                {
                    CheatThread._aimBot.LegitSpeed = UiHorizontalSlider(CheatThread._aimBot.LegitSpeed, "平滑速度", 1f, 600f);
                }
                CheatThread._aimBot.aimRange = UiHorizontalSlider(CheatThread._aimBot.aimRange, "自瞄范围", 1, 500);
                GUILayout.Space(15f);
                CheatThread._aimBot.AimPosMode = DrawDropdown("瞄准部位", CheatThread._aimBot.AimPosMode, EyeRecall.Helper.config.aimPosText, ref aimPosDropdown);
                GUILayout.Space(15f);
                CheatThread._aimBot.aimbotKey = DrawKeybindButton("自瞄热键", CheatThread._aimBot.aimbotKey, ref isWaitingForAimKey);
            }
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static void DrawRageAimbotTab()
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[] { GUILayout.Width(450f) });
            GUILayout.Label("核心设置", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._rageBot.Enable = UiToggle(CheatThread._rageBot.Enable, "启用暴力自瞄");
            if (CheatThread._rageBot.Enable)
            {
                CheatThread._rageBot.Resolver = UiToggle(CheatThread._rageBot.Resolver, "启用解析器");
                CheatThread._rageBot.ManualTiggerbot = UiToggle(CheatThread._rageBot.ManualTiggerbot, "中键手动开火");
                CheatThread._rageBot.Multiplehitbox = UiToggle(CheatThread._rageBot.Multiplehitbox, "多部位漏打补偿");
            }
            GUILayout.EndVertical();
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
            GUILayout.Label("参数调整", sectionTitleStyle, new GUILayoutOption[0]);
            if (CheatThread._rageBot.Enable)
            {
                CheatThread._rageBot.Accurary = UiHorizontalSlider(CheatThread._rageBot.Accurary, "命中率", 0f, 80f);
                CheatThread._rageBot.a_resolovertype = DrawDropdown("解析类型", CheatThread._rageBot.a_resolovertype, EyeRecall.Helper.config.ResolverModeText, ref resolverType);
                if (CheatThread._rageBot.a_resolovertype == 1)
                {
                    GUILayout.Label("提示: 侧键解析抬头/低头", labelStyle, new GUILayoutOption[0]);
                }
                if (CheatThread._rageBot.a_resolovertype == 2)
                {
                    GUILayout.Label("提示: 50%概率无视真假头", labelStyle, new GUILayoutOption[0]);
                }
                GUILayout.Space(15f);
                if (GUILayout.Button("选择命中部位", buttonStyle, new GUILayoutOption[0]))
                {
                    rageBotPosDropdown = !rageBotPosDropdown;
                }
                if (rageBotPosDropdown)
                {
                    rageBotPosScrollPosition = GUILayout.BeginScrollView(rageBotPosScrollPosition, new GUILayoutOption[] { GUILayout.Height(200f) });
                    for (int i = 0; i < EyeRecall.Helper.config.rageBotPosText.Length; i++)
                    {
                        CheatThread._rageBot.aimPos[i] = UiToggle(CheatThread._rageBot.aimPos[i], EyeRecall.Helper.config.rageBotPosText[i]);
                    }
                    GUILayout.EndScrollView();
                }
            }
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static void DrawVisualsTab()
        {
            CheatThread._Visual.Enable = UiToggle(CheatThread._Visual.Enable, "启用视觉辅助");
            if (!CheatThread._Visual.Enable)
            {
                return;
            }
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[] { GUILayout.Width(450f) });
            GUILayout.Label("玩家透视", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._Visual.showBox = UiToggle(CheatThread._Visual.showBox, "方框");
            CheatThread._Visual.showName = UiToggle(CheatThread._Visual.showName, "昵称");
            CheatThread._Visual.showHp = UiToggle(CheatThread._Visual.showHp, "血条");
            CheatThread._Visual.showWeapon = UiToggle(CheatThread._Visual.showWeapon, "武器");
            CheatThread._Visual.showC4 = UiToggle(CheatThread._Visual.showC4, "C4携带者");
            CheatThread._Visual.showAngle = UiToggle(CheatThread._Visual.showAngle, "显示角度");
            GUILayout.EndVertical();
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
            GUILayout.Label("其他视觉", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._Visual.showAimRange = UiToggle(CheatThread._Visual.showAimRange, "自瞄范围圈");
            CheatThread._Visual.glow = UiToggle(CheatThread._Visual.glow, "人物发光");
            if (CheatThread._Visual.glow)
            {
                CheatThread._Visual.glowColorMode = DrawDropdown("  发光颜色", CheatThread._Visual.glowColorMode, EyeRecall.Helper.config.glowColorOptions, ref glowColorDropdown);
            }
            CheatThread._Visual.showRadar = UiToggle(CheatThread._Visual.showRadar, "雷达");
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        // ==================== 滚动列表式配置管理（完全不动）====================
        private static void DrawMiscTab()
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[] { GUILayout.Width(450f) });
            GUILayout.Label("功能", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._misc.noRecoil = UiToggle(CheatThread._misc.noRecoil, "智能压枪");
            CheatThread._misc.bhop = UiToggle(CheatThread._misc.bhop, "自动连跳");
            if (CheatThread._misc.bhop)
            {
                CheatThread._misc.bhoptype = DrawDropdown("  连跳类型", CheatThread._misc.bhoptype, EyeRecall.Helper.config.bhopModeText, ref bhopModeDropdown);
            }
            CheatThread._misc.InstanceSniper = UiToggle(CheatThread._misc.InstanceSniper, "右键瞬狙");
            CheatThread._misc.tiggerBot = UiToggle(CheatThread._misc.tiggerBot, "自动扳机");
            if (CheatThread._misc.tiggerBot)
            {
                CheatThread._misc.tiggerBotDelayedTime = UiHorizontalSlider(CheatThread._misc.tiggerBotDelayedTime, "  扳机延迟", 1, 250);
            }
            CheatThread._misc.gHost = UiToggle(CheatThread._misc.gHost, "滑步");
            CheatThread._misc.shieldbayonet = UiToggle(CheatThread._misc.shieldbayonet, "屏蔽刺刀");
            CheatThread._misc.thirdPerson = UiToggle(CheatThread._misc.thirdPerson, "第三人称");
            if (CheatThread._misc.thirdPerson)
            {
                CheatThread._misc.thirdPersonKey = DrawKeybindButton("  切换热键", CheatThread._misc.thirdPersonKey, ref isWaitingForThirdPressKey);
            }
            CheatThread._misc.fakeFov = UiToggle(CheatThread._misc.fakeFov, "修改视野");
            if (CheatThread._misc.fakeFov)
            {
                CheatThread._misc.fovValue = UiHorizontalSlider(CheatThread._misc.fovValue, "  视野值", 30, 175);
            }
            CheatThread._misc.fakeLag = UiToggle(CheatThread._misc.fakeLag, "假性延迟");
            if (CheatThread._misc.fakeLag)
            {
                CheatThread._misc.fakeLagTick = UiHorizontalSlider(CheatThread._misc.fakeLagTick, "  延迟量", 0, 300);
            }
            GUILayout.EndVertical();
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
            GUILayout.Label("魔法攻击", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._misc.autoChatEnable = UiToggle(CheatThread._misc.autoChatEnable, "启用自动喊话");
            if (CheatThread._misc.autoChatEnable)
            {
                CheatThread._misc.autoChatDelay = UiHorizontalSlider(CheatThread._misc.autoChatDelay, "喊话间隔 (毫秒)", 100, 10000);
                GUILayout.Label("喊话内容:", new GUILayoutOption[0]);
                autoChatMessageScrollPosition = GUILayout.BeginScrollView(autoChatMessageScrollPosition, new GUILayoutOption[] { GUILayout.Height(80f) });
                CheatThread._misc.autoChatMessage = GUILayout.TextArea(CheatThread._misc.autoChatMessage, new GUILayoutOption[] { GUILayout.ExpandHeight(true) });
                GUILayout.EndScrollView();
            }

            GUILayout.Space(30f);
            GUILayout.Label("配置管理", sectionTitleStyle, new GUILayoutOption[0]);

            RefreshConfigList();
            bool hasConfig = EyeRecall.Helper.config._config != null && EyeRecall.Helper.config._config.Length > 0;
            string[] configFileNames = hasConfig ? EyeRecall.Helper.config._config.Select(Path.GetFileName).ToArray() : Array.Empty<string>();

            if (hasConfig && (EyeRecall.Helper.config._configKey < 0 || EyeRecall.Helper.config._configKey >= EyeRecall.Helper.config._config.Length))
            {
                EyeRecall.Helper.config._configKey = 0;
                lastSelectedConfigKey = 0;
            }

            GUILayout.Label("配置列表（点击选中）", labelStyle);
            configScrollPosition = GUILayout.BeginScrollView(configScrollPosition, GUILayout.Height(180f));
            if (hasConfig)
            {
                for (int i = 0; i < configFileNames.Length; i++)
                {
                    bool isSelected = EyeRecall.Helper.config._configKey == i;
                    if (GUILayout.Button(configFileNames[i], isSelected ? configSelectedStyle : buttonStyle))
                    {
                        EyeRecall.Helper.config._configKey = i;
                        EyeRecall.Helper.config.configTitle = Path.GetFileNameWithoutExtension(configFileNames[i]);
                        lastSelectedConfigKey = i;
                        Debug.Log("选中配置: " + configFileNames[i]);
                    }
                }
            }
            else
            {
                GUILayout.Label("暂无配置文件，请点击「新建」创建", new GUIStyle(labelStyle)
                {
                    alignment = TextAnchor.MiddleCenter,
                    fontStyle = FontStyle.Italic
                }, GUILayout.Height(180f));
            }
            GUILayout.EndScrollView();

            if (hasConfig)
            {
                GUILayout.Label("当前选中: " + EyeRecall.Helper.config.configTitle, new GUIStyle(labelStyle)
                {
                    fontStyle = FontStyle.Bold,
                    fontSize = 18
                });
            }

            if (isCreatingConfig)
            {
                GUILayout.Space(15f);
                GUILayout.Label("新建配置", sectionTitleStyle, new GUILayoutOption[0]);

                if (hasConfig)
                {
                    GUILayout.Label("基于以下配置新建:", labelStyle, new GUILayoutOption[0]);
                    createConfigSourceIndex = Mathf.Clamp(createConfigSourceIndex, 0, configFileNames.Length - 1);
                    createConfigSourceIndex = (int)GUILayout.HorizontalSlider(createConfigSourceIndex, 0, configFileNames.Length - 1, new GUILayoutOption[0]);
                    GUILayout.Label("源配置: " + configFileNames[createConfigSourceIndex], labelStyle, new GUILayoutOption[0]);
                }

                GUILayout.Space(10f);
                GUILayout.Label("新配置名:", labelStyle, new GUILayoutOption[0]);
                string inputName = GUILayout.TextField(newConfigName, new GUILayoutOption[0]);
                newConfigName = FilterInvalidFileNameChars(inputName);

                GUILayout.BeginHorizontal(new GUILayoutOption[0]);
                if (GUILayout.Button("确认新建", buttonStyle, new GUILayoutOption[0]))
                {
                    CreateNewConfig(hasConfig);
                }
                GUILayout.Space(8f);
                if (GUILayout.Button("取消", buttonStyle, new GUILayoutOption[0]))
                {
                    isCreatingConfig = false;
                    newConfigName = "";
                }
                GUILayout.EndHorizontal();
            }

            if (isRenamingConfig && hasConfig)
            {
                GUILayout.Space(15f);
                GUILayout.Label("新配置名:", labelStyle, new GUILayoutOption[0]);
                string inputName = GUILayout.TextField(renameConfigNewName, new GUILayoutOption[0]);
                renameConfigNewName = FilterInvalidFileNameChars(inputName);

                GUILayout.BeginHorizontal(new GUILayoutOption[0]);
                if (GUILayout.Button("确认改名", buttonStyle, new GUILayoutOption[0]))
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(renameConfigNewName))
                        {
                            Debug.LogWarning("配置名不能为空");
                        }
                        else
                        {
                            string oldFilePath = EyeRecall.Helper.config._config[EyeRecall.Helper.config._configKey];
                            string fileDir = Path.GetDirectoryName(oldFilePath);
                            string fileExt = Path.GetExtension(oldFilePath);

                            string newFileName = renameConfigNewName.Trim();
                            if (!newFileName.EndsWith(fileExt))
                            {
                                newFileName += fileExt;
                            }
                            string newFilePath = Path.Combine(fileDir, newFileName);

                            if (File.Exists(newFilePath))
                            {
                                Debug.LogWarning("已存在同名配置文件");
                            }
                            else
                            {
                                File.Move(oldFilePath, newFilePath);
                                RefreshConfigList();
                                EyeRecall.Helper.config._configKey = Array.IndexOf(EyeRecall.Helper.config._config, newFilePath);
                                EyeRecall.Helper.config.configTitle = Path.GetFileNameWithoutExtension(newFilePath);
                                lastSelectedConfigKey = EyeRecall.Helper.config._configKey;
                                isRenamingConfig = false;
                                renameConfigNewName = "";
                                Debug.Log("配置重命名成功");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError("重命名配置失败: " + ex.Message);
                    }
                }
                GUILayout.Space(8f);
                if (GUILayout.Button("取消", buttonStyle, new GUILayoutOption[0]))
                {
                    isRenamingConfig = false;
                    renameConfigNewName = "";
                }
                GUILayout.EndHorizontal();
            }

            if (isDeletingConfig && hasConfig)
            {
                GUILayout.Space(15f);
                GUIStyle warningStyle = new GUIStyle(labelStyle)
                {
                    normal = { textColor = Color.red },
                    fontSize = 18,
                    fontStyle = FontStyle.Bold
                };
                GUILayout.Label("⚠️ 确认删除该配置？", warningStyle, new GUILayoutOption[0]);
                GUILayout.Label("删除后无法恢复！", warningStyle, new GUILayoutOption[0]);

                GUILayout.BeginHorizontal(new GUILayoutOption[0]);
                GUIStyle deleteButtonStyle = new GUIStyle(buttonStyle);
                deleteButtonStyle.normal.background = MakeTex(2, 2, new Color(0.8f, 0.2f, 0.2f, MenuAlpha + 0.1f));
                deleteButtonStyle.hover.background = MakeTex(2, 2, new Color(1f, 0.3f, 0.3f, MenuAlpha + 0.1f));
                deleteButtonStyle.normal.textColor = Color.white;
                deleteButtonStyle.hover.textColor = Color.white;
                if (GUILayout.Button("确认删除", deleteButtonStyle, new GUILayoutOption[0]))
                {
                    try
                    {
                        string deletePath = EyeRecall.Helper.config._config[EyeRecall.Helper.config._configKey];
                        File.Delete(deletePath);
                        RefreshConfigList();
                        if (EyeRecall.Helper.config._config.Length > 0)
                        {
                            EyeRecall.Helper.config._configKey = 0;
                            EyeRecall.Helper.config.configTitle = Path.GetFileNameWithoutExtension(EyeRecall.Helper.config._config[0]);
                            lastSelectedConfigKey = 0;
                        }
                        else
                        {
                            EyeRecall.Helper.config.configTitle = "";
                            lastSelectedConfigKey = -1;
                            EyeRecall.Helper.config._configKey = -1;
                        }
                        isDeletingConfig = false;
                        Debug.Log("配置删除成功: " + Path.GetFileName(deletePath));
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError("删除配置失败: " + ex.Message);
                    }
                }
                GUILayout.Space(8f);
                if (GUILayout.Button("取消", buttonStyle, new GUILayoutOption[0]))
                {
                    isDeletingConfig = false;
                }
                GUILayout.EndHorizontal();
            }

            GUILayout.FlexibleSpace();
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);

            if (GUILayout.Button("刷新", buttonStyle, new GUILayoutOption[0]))
            {
                RefreshConfigList();
                Debug.Log("配置列表已刷新");
            }
            GUILayout.Space(8f);

            if (GUILayout.Button("新建", buttonStyle, new GUILayoutOption[0]))
            {
                isCreatingConfig = true;
                isRenamingConfig = false;
                isDeletingConfig = false;
                newConfigName = "新配置";
                if (hasConfig)
                {
                    createConfigSourceIndex = EyeRecall.Helper.config._configKey;
                }
            }
            GUILayout.Space(8f);

            if (hasConfig)
            {
                if (GUILayout.Button("加载", buttonStyle, new GUILayoutOption[0]))
                {
                    EyeRecall.Helper.config.LoadConfig();
                    EyeRecall.Helper.config.configTitle = Path.GetFileNameWithoutExtension(EyeRecall.Helper.config._config[EyeRecall.Helper.config._configKey]);
                    lastSelectedConfigKey = EyeRecall.Helper.config._configKey;
                    Debug.Log("手动加载配置成功: " + EyeRecall.Helper.config.configTitle);
                }
                GUILayout.Space(8f);

                if (GUILayout.Button("保存", buttonStyle, new GUILayoutOption[0]))
                {
                    EyeRecall.Helper.config.WriteConfig();
                    RefreshConfigList();
                    Debug.Log("配置保存成功: " + EyeRecall.Helper.config.configTitle);
                }
                GUILayout.Space(8f);

                if (GUILayout.Button("改名", buttonStyle, new GUILayoutOption[0]))
                {
                    isRenamingConfig = true;
                    isCreatingConfig = false;
                    isDeletingConfig = false;
                    string currentFileName = Path.GetFileNameWithoutExtension(EyeRecall.Helper.config._config[EyeRecall.Helper.config._configKey]);
                    renameConfigNewName = currentFileName;
                }
                GUILayout.Space(8f);

                GUIStyle deleteBtnStyle = new GUIStyle(buttonStyle);
                deleteBtnStyle.normal.background = MakeTex(2, 2, new Color(0.7f, 0.2f, 0.2f, MenuAlpha));
                deleteBtnStyle.hover.background = MakeTex(2, 2, new Color(0.9f, 0.3f, 0.3f, MenuAlpha));
                deleteBtnStyle.normal.textColor = Color.white;
                deleteBtnStyle.hover.textColor = Color.white;
                if (GUILayout.Button("删除", deleteBtnStyle, new GUILayoutOption[0]))
                {
                    isDeletingConfig = true;
                    isCreatingConfig = false;
                    isRenamingConfig = false;
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static void DrawAntiAimTab()
        {
            CheatThread._antiAim.Enable = UiToggle(CheatThread._antiAim.Enable, "启用反自瞄");
            if (!CheatThread._antiAim.Enable)
            {
                return;
            }
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[] { GUILayout.Width(450f) });
            GUILayout.Label("模式选择", sectionTitleStyle, new GUILayoutOption[0]);
            CheatThread._antiAim.AntiAimMode = DrawDropdown("基础类型", CheatThread._antiAim.AntiAimMode, EyeRecall.Helper.config.AntiAimModeText, ref antiAimModeDropdown);
            CheatThread._antiAim.AntiAimPitchMode = DrawDropdown("俯仰轴", CheatThread._antiAim.AntiAimPitchMode, EyeRecall.Helper.config.AntiAimPitchModeText, ref antiAimPitchModeDropdown);
            CheatThread._antiAim.AntiAimYawMode = DrawDropdown("偏航轴", CheatThread._antiAim.AntiAimYawMode, EyeRecall.Helper.config.AntiAimYawModeText, ref antiAimYawModeDropdown);
            GUILayout.EndVertical();
            GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
            GUILayout.Label("偏航轴参数", sectionTitleStyle, new GUILayoutOption[0]);
            switch (CheatThread._antiAim.AntiAimYawMode)
            {
                case 0:
                case 2:
                    CheatThread._antiAim.fakeYaw = UiHorizontalSlider(CheatThread._antiAim.fakeYaw, "偏航角度", -180, 180);
                    if (CheatThread._antiAim.AntiAimYawMode == 2)
                    {
                        CheatThread._antiAim.JitterMax = UiHorizontalSlider(CheatThread._antiAim.JitterMax, "抖动最大值", -180, 180);
                        CheatThread._antiAim.JitterMin = UiHorizontalSlider(CheatThread._antiAim.JitterMin, "抖动最小值", -180, 180);
                    }
                    break;
                case 1:
                    CheatThread._antiAim.RotateSpeed = UiHorizontalSlider(CheatThread._antiAim.RotateSpeed, "旋转速度", 1, 1000);
                    break;
            }
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        // 新建配置方法
        private static void CreateNewConfig(bool hasExistingConfig)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(newConfigName))
                {
                    Debug.LogWarning("配置名不能为空");
                    return;
                }

                string configDir = Environment.CurrentDirectory;
                if (hasExistingConfig && EyeRecall.Helper.config._config.Length > 0)
                {
                    configDir = Path.GetDirectoryName(EyeRecall.Helper.config._config[0]);
                }

                if (!Directory.Exists(configDir))
                {
                    Directory.CreateDirectory(configDir);
                    Debug.Log("创建配置目录: " + configDir);
                }

                string fileExt = ".cfg";
                string newFileName = newConfigName.Trim();
                if (!newFileName.EndsWith(fileExt))
                {
                    newFileName += fileExt;
                }
                string newFilePath = Path.Combine(configDir, newFileName);

                if (File.Exists(newFilePath))
                {
                    Debug.LogWarning("已存在同名配置文件");
                    return;
                }

                if (hasExistingConfig)
                {
                    File.Copy(EyeRecall.Helper.config._config[createConfigSourceIndex], newFilePath);
                }
                else
                {
                    File.Create(newFilePath).Dispose();
                    if (EyeRecall.Helper.config._config == null || EyeRecall.Helper.config._config.Length == 0)
                    {
                        EyeRecall.Helper.config._config = new string[] { newFilePath };
                    }
                    EyeRecall.Helper.config._configKey = 0;
                    EyeRecall.Helper.config.WriteConfig();
                }

                RefreshConfigList();
                EyeRecall.Helper.config._configKey = Array.IndexOf(EyeRecall.Helper.config._config, newFilePath);
                EyeRecall.Helper.config.configTitle = Path.GetFileNameWithoutExtension(newFilePath);
                lastSelectedConfigKey = EyeRecall.Helper.config._configKey;
                isCreatingConfig = false;
                newConfigName = "";
                Debug.Log("新建配置成功: " + newFileName);
            }
            catch (Exception ex)
            {
                Debug.LogError("新建配置失败: " + ex.Message);
            }
        }

        private static bool CheckMouse()
        {
            return Input.GetKeyDown(KeyCode.Mouse0) || Input.GetKeyDown(KeyCode.Mouse1) || Input.GetKeyDown(KeyCode.Mouse2) || Input.GetKeyDown(KeyCode.Mouse3) || Input.GetKeyDown(KeyCode.Mouse4);
        }

        private static void DrawGradientBackground(Rect rect)
        {
            if (s_gradientBackgroundTex != null)
            {
                GUI.DrawTexture(rect, s_gradientBackgroundTex);
            }
        }

        private static void DrawNeonBorder(Rect rect)
        {
            borderColorTime += Time.deltaTime * 0.75f;
            Color color = Color.HSVToRGB(Mathf.Repeat(borderColorTime, 1f), 0.9f, 1f);
            color.a = 0.9f + 0.1f * ((Mathf.Sin(Time.time * 4f) + 1f) / 2f);
            GUI.color = color;
            float num = 3f;
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, num), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - num, rect.width, num), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y, num, rect.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x + rect.width - num, rect.y, num, rect.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        private static Texture2D MakeTex(int width, int height, Color col)
        {
            Color[] array = new Color[width * height];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = col;
            }
            Texture2D texture2D = new Texture2D(width, height);
            texture2D.SetPixels(array);
            texture2D.Apply();
            texture2D.hideFlags = HideFlags.HideAndDontSave;
            return texture2D;
        }

        private static bool UiToggle(bool value, string label)
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            Rect rect = GUILayoutUtility.GetRect(toggleStyle.fixedWidth, toggleStyle.fixedHeight);
            bool flag = GUI.Toggle(rect, value, GUIContent.none, toggleStyle);
            GUI.Box(new Rect(rect.x + (flag ? (rect.width - toggleKnobStyle.fixedWidth - 3f) : 3f), rect.y + (rect.height - toggleKnobStyle.fixedHeight) / 2f, toggleKnobStyle.fixedWidth, toggleKnobStyle.fixedHeight), GUIContent.none, toggleKnobStyle);
            GUILayout.Space(15f);
            if (GUILayout.Button(label, new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleLeft,
                fontSize = 16
            }, new GUILayoutOption[0]))
            {
                flag = !flag;
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.Space(12f);
            return flag;
        }

        private static int UiHorizontalSlider(int value, string label, int min, int max)
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.Label(label, labelStyle, new GUILayoutOption[] { GUILayout.Width(150f) });
            int num = (int)GUILayout.HorizontalSlider((float)value, (float)min, (float)max, new GUILayoutOption[] { GUILayout.ExpandWidth(true) });
            GUILayout.Label(num.ToString(), sliderLabelStyle, new GUILayoutOption[] { GUILayout.Width(50f) });
            GUILayout.EndHorizontal();
            GUILayout.Space(12f);
            return num;
        }

        private static float UiHorizontalSlider(float value, string label, float min, float max)
        {
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.Label(label, labelStyle, new GUILayoutOption[] { GUILayout.Width(150f) });
            float num = GUILayout.HorizontalSlider(value, min, max, new GUILayoutOption[] { GUILayout.ExpandWidth(true) });
            GUILayout.Label(string.Format("{0:F1}", num), sliderLabelStyle, new GUILayoutOption[] { GUILayout.Width(50f) });
            GUILayout.EndHorizontal();
            GUILayout.Space(12f);
            return num;
        }

        private static string DrawKeybindButton(string label, string currentKey, ref bool isWaiting)
        {
            string text = currentKey;
            GUILayout.BeginHorizontal(new GUILayoutOption[0]);
            GUILayout.Label(label, labelStyle, new GUILayoutOption[] { GUILayout.Width(150f) });
            if (GUILayout.Button(isWaiting ? waitingText : text, buttonStyle, new GUILayoutOption[] { GUILayout.ExpandWidth(true) }))
            {
                isWaiting = !isWaiting;
            }
            if (isWaiting)
            {
                if (Event.current.isKey && Event.current.keyCode != KeyCode.None)
                {
                    text = Event.current.keyCode.ToString();
                    isWaiting = false;
                }
                else if (CheckMouse())
                {
                    if (Input.GetKeyDown(KeyCode.Mouse0))
                    {
                        text = "Mouse0";
                    }
                    else if (Input.GetKeyDown(KeyCode.Mouse1))
                    {
                        text = "Mouse1";
                    }
                    else if (Input.GetKeyDown(KeyCode.Mouse2))
                    {
                        text = "Mouse2";
                    }
                    else if (Input.GetKeyDown(KeyCode.Mouse3))
                    {
                        text = "Mouse3";
                    }
                    else if (Input.GetKeyDown(KeyCode.Mouse4))
                    {
                        text = "Mouse4";
                    }
                    isWaiting = false;
                }
            }
            GUILayout.EndHorizontal();
            GUILayout.Space(12f);
            return text;
        }

        // 下拉框方法（给其他功能用）
        private static int DrawDropdown(string label, int selectedIndex, string[] options, ref bool isOpen)
        {
            int num = selectedIndex;
            GUILayout.BeginVertical(new GUILayoutOption[0]);
            string text = ((num >= 0 && num < options.Length) ? options[num] : "无");
            if (GUILayout.Button(label + ": " + text, buttonStyle, new GUILayoutOption[0]))
            {
                isOpen = !isOpen;
                GUIUtility.keyboardControl = 0;
            }
            if (isOpen)
            {
                int oldDepth = GUI.depth;
                GUI.depth = oldDepth - 50;

                GUILayout.BeginVertical(sectionBoxStyle, new GUILayoutOption[0]);
                for (int i = 0; i < options.Length; i++)
                {
                    if (GUILayout.Button(options[i], buttonStyle, new GUILayoutOption[0]))
                    {
                        num = i;
                        isOpen = false;
                        GUIUtility.keyboardControl = 0;
                    }
                }
                GUILayout.EndVertical();

                GUI.depth = oldDepth;
            }
            GUILayout.EndVertical();
            return num;
        }

        private static string FilterInvalidFileNameChars(string fileName)
        {
            char[] invalidChars = Path.GetInvalidFileNameChars();
            return new string(fileName.Where(c => !invalidChars.Contains(c)).ToArray());
        }

        private static void RefreshConfigList()
        {
            try
            {
                string configDir = Environment.CurrentDirectory;
                if (EyeRecall.Helper.config._config != null && EyeRecall.Helper.config._config.Length > 0)
                {
                    configDir = Path.GetDirectoryName(EyeRecall.Helper.config._config[0]);
                }

                if (!Directory.Exists(configDir))
                {
                    Directory.CreateDirectory(configDir);
                }

                string[] configFiles = Directory.GetFiles(configDir, "*.cfg", SearchOption.TopDirectoryOnly);
                EyeRecall.Helper.config._config = configFiles;
            }
            catch (Exception ex)
            {
                Debug.LogError("刷新配置列表失败: " + ex.Message);
            }
        }
    }
}